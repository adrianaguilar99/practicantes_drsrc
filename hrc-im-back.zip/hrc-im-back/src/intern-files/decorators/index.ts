export { UploadInternFiles } from './upload-file.decorator';
