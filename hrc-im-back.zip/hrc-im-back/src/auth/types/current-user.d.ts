import { UserRole } from 'src/common';

export type CurrentUser = {
  id: string;
  userRole: UserRole;
};
