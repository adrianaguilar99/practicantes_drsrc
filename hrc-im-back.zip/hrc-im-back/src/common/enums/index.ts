export { AttendanceStatuses } from './attendance-statuses.enum';

export { BloodType } from './intern-blood-type.enum';

export { InternStatus } from './intern-status.enum';

export { UserRole } from './user-role.enum';
