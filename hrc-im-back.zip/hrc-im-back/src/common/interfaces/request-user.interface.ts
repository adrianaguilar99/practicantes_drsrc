export interface IRequestUser {
  userId: string;
  fullName: string;
  role: string;
}
