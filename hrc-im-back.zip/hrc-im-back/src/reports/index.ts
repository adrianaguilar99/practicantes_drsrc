export * from './interns.report';
export * from './type-intern.report';
export * from './intern-by-id.report';
