import { existsSync, mkdirSync } from 'fs';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { normalizeString } from 'src/common/utils';
import { fileFilter } from 'src/intern-files/helpers';
import { ENV } from './env.config';

const multerOptions = {
  storage: diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = `${ENV.INTERN_FILES_PATH}${req.params.internId}`;
      // console.log({ reqFiles: req });

      if (!existsSync(uploadDir)) mkdirSync(uploadDir, { recursive: true });

      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const name = normalizeString(file.originalname.split('.')[0])
        .split(' ')
        .join('-');
      const randomName = Array(32)
        .fill(null)
        .map(() => Math.round(Math.random() * 16).toString(16))
        .join('');
      const extension = extname(file.originalname);
      cb(null, `${name}-${randomName}${extension}`);
    },
  }),
  fileFilter,
};

export default multerOptions;
